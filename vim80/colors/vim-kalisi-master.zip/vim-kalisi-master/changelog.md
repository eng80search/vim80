# Change log

## [0.8] - 2015-09-27

## Fixed Issues:
* Improve support for e-mail quotations #3 @jalvesaq
* Constant and statement keywords are too similar #4 @johntyree
* Comment color in dark color scheme induces pain #5 @kiith-sa
* SpecialKey stands out way too much #7 @vdrandom

### Changed

Kalisi Dark scheme

* Normal (brighter foreground color)
* Comment (brighter foreground color)
* Constant
* SpecialKey

Kalisi Light scheme

* Constant
* Define
* SpecialKey

Whitespace formatting

### Added

New Highligh Groups:

* mailHeader
* mailSubject
* mailQuoted1
* mailQuoted2
* mailQuoted3
* mailQuoted4
* mailQuoted5
* mailQuoted6
* mailSignature

